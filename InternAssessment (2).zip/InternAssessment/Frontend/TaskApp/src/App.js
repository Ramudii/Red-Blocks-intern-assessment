﻿// TaskApp/src/App.js
import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  // Fetch tasks from API
  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    try {
      const response = await fetch('https://localhost:7191/api/tasks');
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.log('Error loading tasks:', error);
    }
  }

  async function addTask() {
    if (!title.trim()) return;
    
    const newTask = {
      title: title,
      description: description,
      isCompleted: false
    };

    try {
      const response = await fetch('https://localhost:7191/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTask)
      });

      if (response.ok) {
        setTitle('');
        setDescription('');
        fetchData(); // Refresh list
      }
    } catch (error) {
      console.log('Error saving task:', error);
    }
  }

  return (
    <div className="app-container">
      <h1>My Task Manager</h1>
      
      <div className="task-form">
        <h3>Add New Task</h3>
        <div className="form-group">
          <label>Title:</label>
          <input 
            type="text" 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter task title"
          />
        </div>
        
        <div className="form-group">
          <label>Description:</label>
          <textarea 
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter task details"
            rows="3"
          />
        </div>
        
        <button onClick={addTask} className="submit-btn">
          Add Task
        </button>
      </div>

      <div className="task-list">
        <h3>My Tasks ({tasks.length})</h3>
        {tasks.length === 0 ? (
          <p>No tasks yet. Add one above!</p>
        ) : (
          tasks.map(task => (
            <div key={task.id} className="task-item">
              <div className="task-header">
                <span className="task-title">{task.title}</span>
                <span className={`status ${task.isCompleted ? 'completed' : 'pending'}`}>
                  {task.isCompleted ? '✓ Done' : '… Pending'}
                </span>
              </div>
              <p className="task-desc">{task.description}</p>
              <div className="task-id">ID: {task.id}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default App;