// TaskAPI/Controllers/TasksController.cs
using Microsoft.AspNetCore.Mvc;
using TaskAPI.Models;

namespace TaskAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        // Simple in-memory list (like a database)
        private static List<TaskItem> tasks = new List<TaskItem>();
        private static int nextId = 1;

        // GET: api/tasks
        [HttpGet]
        public IActionResult GetTasks()
        {
            // Return all tasks
            return Ok(tasks);
        }

        // POST: api/tasks
        [HttpPost]
        public async Task<IActionResult> CreateTask(TaskItem newTask)
        {
            // Async example: simulate database delay
            await Task.Delay(100);

            // Assign ID and add to list
            newTask.Id = nextId++;
            tasks.Add(newTask);

            return CreatedAtAction(nameof(GetTasks), new { id = newTask.Id }, newTask);
        }
    }
}